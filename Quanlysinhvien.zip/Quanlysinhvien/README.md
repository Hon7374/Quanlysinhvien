# Hệ thống Quản lý Sinh viên - Student Management System

## Giới thiệu
Hệ thống quản lý sinh viên được xây dựng bằng WinForms (C# .NET 6.0) với SQL Server, cung cấp giao diện cho 3 loại người dùng: Admin, Giảng viên và Sinh viên.

## Tính năng chính

### 1. Admin Dashboard
- Quản lý tổng quan hệ thống
- Quản lý sinh viên (thêm, sửa, xóa, tìm kiếm)
- Quản lý giảng viên
- Quản lý môn học và khóa học
- Quản lý tài khoản người dùng
- Báo cáo và thống kê

### 2. Teacher Dashboard (Giảng viên)
- Xem thông tin cá nhân
- Xem danh sách môn học đang giảng dạy
- Xem danh sách sinh viên theo từng môn học
- Nhập và quản lý điểm số
- Xem báo cáo kết quả học tập

### 3. Student Dashboard (Sinh viên)
- Xem thông tin cá nhân
- Đăng ký môn học
- Xem danh sách môn học đã đăng ký
- Xem điểm số và kết quả học tập
- Xem GPA (Grade Point Average)
- Xem lịch học

## Yêu cầu hệ thống

### Phần mềm cần thiết:
1. **Visual Studio 2022** hoặc mới hơn
2. **.NET 6.0 SDK** trở lên
3. **SQL Server 2019** hoặc **SQL Server Express**
4. **SQL Server Management Studio (SSMS)** (tùy chọn, để quản lý database)

## Cài đặt và Chạy ứng dụng

### Bước 1: Cài đặt SQL Server
1. Tải và cài đặt SQL Server hoặc SQL Server Express
2. Trong quá trình cài đặt, nhớ chọn chế độ xác thực "Windows Authentication" hoặc "Mixed Mode"

### Bước 2: Tạo Database
1. Mở SQL Server Management Studio (SSMS)
2. Kết nối tới SQL Server instance của bạn
3. Mở file `Database/CreateDatabase.sql`
4. Chạy script này để tạo database và dữ liệu mẫu

### Bước 3: Cấu hình Connection String
1. Mở file `App.config`
2. Chỉnh sửa connection string phù hợp với SQL Server của bạn:

```xml
<add name="StudentManagementDB"
     connectionString="Data Source=.;Initial Catalog=StudentManagementDB;Integrated Security=True;TrustServerCertificate=True"
     providerName="System.Data.SqlClient"/>
```

**Lưu ý các tùy chọn Data Source:**
- `.` hoặc `(local)` - SQL Server local với Windows Authentication
- `localhost\SQLEXPRESS` - SQL Express local
- `tên_máy_chủ` - SQL Server trên máy remote

**Nếu dùng SQL Authentication:**
```xml
<add name="StudentManagementDB"
     connectionString="Data Source=.;Initial Catalog=StudentManagementDB;User Id=sa;Password=your_password;TrustServerCertificate=True"
     providerName="System.Data.SqlClient"/>
```

### Bước 4: Build và chạy ứng dụng
1. Mở `StudentManagement.sln` trong Visual Studio
2. Restore NuGet packages (Build > Restore NuGet Packages)
3. Build solution (Build > Build Solution hoặc Ctrl+Shift+B)
4. Chạy ứng dụng (Debug > Start Debugging hoặc F5)

## Tài khoản mẫu

Sau khi chạy script `CreateDatabase.sql`, hệ thống sẽ có sẵn 3 tài khoản mẫu:

### Admin
- **Username:** `admin`
- **Password:** `admin123`

### Giảng viên
- **Username:** `teacher01`
- **Password:** `teacher123`

### Sinh viên
- **Username:** `student01`
- **Password:** `student123`

## Cấu trúc dự án

```
QuanLySinhVien/
│
├── Models/                 # Các class model (User, Student, Teacher, Course, etc.)
│   ├── User.cs
│   ├── Student.cs
│   ├── Teacher.cs
│   ├── Course.cs
│   ├── Enrollment.cs
│   └── Grade.cs
│
├── Forms/                  # Các form WinForms
│   ├── LoginForm.cs
│   ├── AdminDashboard.cs
│   ├── TeacherDashboard.cs
│   └── StudentDashboard.cs
│
├── Data/                   # Data access layer
│   └── DatabaseHelper.cs
│
├── Helpers/                # Helper classes
│   ├── PasswordHelper.cs
│   └── SessionManager.cs
│
├── Database/               # SQL scripts
│   └── CreateDatabase.sql
│
├── Program.cs              # Entry point
├── App.config              # Configuration file
└── StudentManagement.csproj # Project file
```

## Database Schema

### Bảng Users
Lưu thông tin đăng nhập và thông tin chung của người dùng

### Bảng Students
Lưu thông tin chi tiết của sinh viên

### Bảng Teachers
Lưu thông tin chi tiết của giảng viên

### Bảng Courses
Lưu thông tin môn học/khóa học

### Bảng Enrollments
Lưu thông tin đăng ký môn học của sinh viên

### Bảng Grades
Lưu thông tin điểm số và đánh giá

## Tính năng nổi bật

1. **Authentication & Authorization** - Hệ thống đăng nhập với phân quyền theo role
2. **Session Management** - Quản lý phiên đăng nhập người dùng
3. **Modern UI** - Giao diện hiện đại với màu sắc phân biệt theo role
4. **Data Grid Views** - Hiển thị dữ liệu dạng bảng dễ xem
5. **CRUD Operations** - Đầy đủ chức năng thêm, sửa, xóa dữ liệu
6. **Grade Calculation** - Tính toán điểm tự động theo tỷ lệ
7. **Course Registration** - Sinh viên có thể đăng ký môn học trực tuyến

## Phát triển tiếp

Các tính năng có thể bổ sung:
- [ ] Quản lý lịch học và phòng học
- [ ] In ấn báo cáo và bảng điểm
- [ ] Export dữ liệu ra Excel/PDF
- [ ] Thông báo và nhắc nhở
- [ ] Quản lý học phí
- [ ] Chức năng chat/tin nhắn
- [ ] Mã hóa mật khẩu bằng BCrypt
- [ ] Forgot password functionality
- [ ] Email notifications
- [ ] Mobile responsive dashboard

## Lỗi thường gặp

### Lỗi kết nối database
**Triệu chứng:** "Cannot connect to database"
**Giải pháp:**
1. Kiểm tra SQL Server đang chạy
2. Kiểm tra connection string trong App.config
3. Kiểm tra firewall không chặn SQL Server

### Lỗi build project
**Triệu chứng:** Build failed with errors
**Giải pháp:**
1. Restore NuGet packages
2. Clean và Rebuild solution
3. Kiểm tra .NET 6.0 SDK đã được cài đặt

## Liên hệ & Hỗ trợ

Nếu gặp vấn đề hoặc cần hỗ trợ, vui lòng tạo issue trên GitHub repository.

## License

MIT License - Tự do sử dụng cho mục đích học tập và thương mại.
